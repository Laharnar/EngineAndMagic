﻿using UnityEngine;
using NodeEditorFramework;

public class NodeCanvasSceneSave : MonoBehaviour 
{
	public NodeCanvas savedNodeCanvas;
}
