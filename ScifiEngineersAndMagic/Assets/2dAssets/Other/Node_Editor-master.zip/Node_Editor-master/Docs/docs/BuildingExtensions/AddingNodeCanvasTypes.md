
# Custom NodeCanvas

*NOTE: This is experimental and has not reached it's final state yet, many more features to come! This sections is very WIP!* <br>
It is possible to create custom NodeCanvas types to limit specific nodes to. For example, you can create a Dialogue canvas type with own, specific properties and even own traversal routines.
Simply extend the NodeCanvas class and change properties. An example can be found on the branch *[Examples/Dialogue System](https://github.com/Baste-RainGames/Node_Editor/tree/Examples/Dialogue-System)*

